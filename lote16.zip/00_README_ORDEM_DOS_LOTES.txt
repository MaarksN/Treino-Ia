PROMPTS — IMPLEMENTAÇÃO DOS 100 ITENS DO TREINO IA EM LOTES DE 5

Use os arquivos na ordem numérica.
Cada arquivo TXT é um prompt completo para o Codex/Jules executar um lote com exatamente 5 itens.

Regras principais:
1. Um lote por branch/PR/commit.
2. Exatamente 5 itens por lote.
3. Não marcar `implemented_now` sem código funcional + UI/fluxo real + testes + validação.
4. Itens com API externa/hardware/credenciais/schema novo devem ter guard/fundação e NÃO fake implementation.
5. Sempre rodar: git diff --check, npm run lint, npm run typecheck, npm test, npm run build.
6. Criar evidência operacional em .ops por lote.
7. Commitar e fazer push no final de cada lote.

ORDEM DOS LOTES:
- 01_lote_01_recovery_readiness_31_32_36_37_39.txt: Phase 9 Wave 1.1 — Recovery & Readiness Pack — Itens 31, 32, 36, 37, 39
- 02_lote_02_gamification_retention_41_42_44_47_50.txt: Phase 9 Wave 1.2 — Gamification & Retention Pack — Itens 41, 42, 44, 47, 50
- 03_lote_03_ux_pwa_core_interface_11_12_16_17_45.txt: Phase 9 Wave 1.3 — UX/PWA/Core Interface Pack — Itens 11, 12, 16, 17, 45
- 04_lote_04_active_workout_evolution_21_22_23_24_29.txt: Phase 9 Wave 1.4 — Active Workout Evolution Pack — Itens 21, 22, 23, 24, 29
- 05_lote_05_nutrition_lifestyle_33_34_35_38_40.txt: Phase 9 Wave 1.5 — Nutrition & Lifestyle Pack — Itens 33, 34, 35, 38, 40
- 06_lote_06_ui_accessibility_interactions_13_14_15_18_19.txt: Phase 9 Wave 1.6 — UI Accessibility & Interaction Pack — Itens 13, 14, 15, 18, 19
- 07_lote_07_workout_authoring_media_20_25_26_27_28.txt: Phase 9 Wave 1.7 — Workout Authoring & Media Pack — Itens 20, 25, 26, 27, 28
- 08_lote_08_engineering_foundation_01_03_04_09_10.txt: Phase 9 Wave 1.8 — Engineering Foundation Pack — Itens 1, 3, 4, 9, 10
- 09_lote_09_quality_ci_data_architecture_02_05_06_07_08.txt: Phase 9 Wave 1.9 — Quality, CI & Data Architecture Pack — Itens 2, 5, 6, 7, 8
- 10_lote_10_social_content_retention_30_43_46_48_49.txt: Phase 9 Wave 1.10 — Social Content & Retention Pack — Itens 30, 43, 46, 48, 49
- 11_lote_11_advanced_ai_safe_51_52_53_54_55.txt: Phase 10 Wave 2.1 — Advanced AI Safe Foundations Pack — Itens 51, 52, 53, 54, 55
- 12_lote_12_external_ai_integrations_56_57_58_59_60.txt: Phase 10 Wave 2.2 — External AI & Intelligence Pack — Itens 56, 57, 58, 59, 60
- 13_lote_13_monetization_61_62_63_64_65.txt: Phase 10 Wave 2.3 — Monetization Experiments Pack — Itens 61, 62, 63, 64, 65
- 14_lote_14_hardware_ar_iot_66_67_68_69_70.txt: Phase 10 Wave 2.4 — Hardware, AR & IoT Pack — Itens 66, 67, 68, 69, 70
- 15_lote_15_advanced_social_71_72_73_74_75.txt: Phase 10 Wave 2.5 — Advanced Social & Community Pack — Itens 71, 72, 73, 74, 75
- 16_lote_16_remote_gamified_76_77_78_79_80.txt: Phase 10 Wave 2.6 — Remote & Deep Gamification Pack — Itens 76, 77, 78, 79, 80
- 17_lote_17_biohacking_81_82_83_84_85.txt: Phase 11 Wave 3.1 — Biohacking Safe Pack — Itens 81, 82, 83, 84, 85
- 18_lote_18_health_sensors_nutrition_86_87_88_89_90.txt: Phase 11 Wave 3.2 — Health Sensors & Micronutrients Pack — Itens 86, 87, 88, 89, 90
- 19_lote_19_accessibility_inclusion_clinical_91_92_93_94_95.txt: Phase 11 Wave 3.3 — Accessibility, Inclusion & Clinical Export Pack — Itens 91, 92, 93, 94, 95
- 20_lote_20_safety_ecosystem_retrospective_96_97_98_99_100.txt: Phase 11 Wave 3.4 — Safety, Ecosystem & Retrospective Pack — Itens 96, 97, 98, 99, 100
